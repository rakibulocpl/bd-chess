<?php

use App\Livewire\Roles\RoleCreate;
use App\Livewire\Roles\RoleEdit;
use App\Livewire\Roles\RoleIndex;
use App\Livewire\Roles\RoleShow;
use App\Livewire\SchoolApp\ApplicantRegistration;
use App\Livewire\SchoolApp\SchoolAdd;
use App\Livewire\SchoolApp\SchoolIndex;
use App\Livewire\SchoolApp\SchoolNotice;
use App\Livewire\SchoolApp\TeamRegistration;
use App\Livewire\Users\UserCreate;
use App\Livewire\Users\UserEdit;
use App\Livewire\Users\UserIndex;
use App\Livewire\Users\UserShow;
use Illuminate\Support\Facades\Route;
use Livewire\Volt\Volt;

Route::get('/',TeamRegistration::class)->name('home');

Route::view('dashboard', 'dashboard')
    ->middleware(['auth', 'verified'])
    ->name('dashboard');

Route::middleware(['auth'])->group(function () {
    Route::redirect('settings', 'settings/profile');

    Route::get('users',UserIndex::class)->name('users.index')->middleware('can:user.view');
    Route::get('users/create',UserCreate::class)->name('users.create')->middleware('can:user.create');
    Route::get('users/{id}/edit',UserEdit::class)->name('users.edit')->middleware('can:user.edit');
    Route::get('users/{id}',UserShow::class)->name('users.show')->middleware('can:user.view');

    /*roles*/
    Route::get('roles',RoleIndex::class)->name('roles.index')->middleware('can:role.view');
    Route::get('roles/create',RoleCreate::class)->name('roles.create')->middleware('can:role.create');
    Route::get('roles/{id}',RoleShow::class)->name('roles.show')->middleware('can:role.view');
    Route::get('roles/{id}/edit',RoleEdit::class)->name('roles.edit')->middleware('can:role.edit');

    Volt::route('settings/profile', 'settings.profile')->name('settings.profile');
    Volt::route('settings/password', 'settings.password')->name('settings.password');
    Volt::route('settings/appearance', 'settings.appearance')->name('settings.appearance');
});

Route::get('schools/create', SchoolAdd::class)->name('schools.create');

/*application*/
Route::get('application/applicant/register',ApplicantRegistration::class)->name('application.applicantRegister');
Route::get('/notice',SchoolNotice::class)->name('application.notice');


require __DIR__.'/auth.php';
