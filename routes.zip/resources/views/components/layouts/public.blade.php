<x-layouts.auth.public :title="$title ?? null">
    {{ $slot }}
</x-layouts.auth.public>
